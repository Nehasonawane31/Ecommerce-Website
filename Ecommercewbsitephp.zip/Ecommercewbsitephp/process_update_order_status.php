
<?php
require 'db.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $status = pg_escape_string($_POST['status']);
    $query = "UPDATE orders SET status = '$status' WHERE id = $id";
    $result = pg_query($conn, $query);
    if (!$result) {
        die("Error in SQL query: " . pg_last_error());
    }
    header('Location: manage_orders.php');
}
?>


