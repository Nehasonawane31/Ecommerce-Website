



 <?php
require 'db.php';
require 'header.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Shopping Cart</title>
</head>
<body>
    <h1>Your Shopping Cart</h1>
    <table>
        <tr>
            <th>Product ID</th>
            <th>Name</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Subtotal</th>
        </tr>
        <?php
        $total = 0;
        if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
            foreach ($_SESSION['cart'] as $product_id => $quantity) {
                $query = "SELECT * FROM products WHERE id = $product_id";
                $result = pg_query($conn, $query);
                $product = pg_fetch_assoc($result);
                if ($product) {
                    $subtotal = $product['price'] * $quantity;
                    $total += $subtotal;
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($product['id']) . "</td>";
                    echo "<td>" . htmlspecialchars($product['name']) . "</td>";
                    echo "<td>" . htmlspecialchars($quantity) . "</td>";
                    echo "<td>$" . htmlspecialchars($product['price']) . "</td>";
                    echo "<td>$$subtotal</td>";
                    echo "</tr>";
                }
            }
        } else {
            echo "<tr><td colspan='5'>Your cart is empty.</td></tr>";
        }
        ?>
    </table>
    <h2>Total: $<?php echo $total; ?></h2>
</body>
</html>

<?php require 'footer.php'; ?>
