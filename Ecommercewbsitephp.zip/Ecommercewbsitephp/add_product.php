<?php
require 'db.php';
require 'header.php';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $price = htmlspecialchars($_POST['price']);
    $image = $_FILES['image'];

    // Upload image
    if ($image['error'] == UPLOAD_ERR_OK) {
        $upload_dir = 'images/';
        $image_path = $upload_dir . basename($image['name']);
        move_uploaded_file($image['tmp_name'], $image_path);
        $image_name = basename($image['name']);
    } else {
        $image_name = null; // Handle the error appropriately
    }

    // Insert product into the database
    $query = "INSERT INTO products (name, price, image) VALUES ('$name', '$price', '$image_name')";
    pg_query($conn, $query);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Product</title>
</head>
<body>
    <h1>Add Product</h1>
    <form action="add_product.php" method="post" enctype="multipart/form-data">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required><br>
        <label for="price">Price:</label>
        <input type="text" id="price" name="price" required><br>
        <label for="image">Image:</label>
        <input type="file" id="image" name="image" accept="image/*" required><br>
        <input type="submit" value="Add Product">
    </form>
</body>
</html>

<?php require 'footer.php'; ?>
