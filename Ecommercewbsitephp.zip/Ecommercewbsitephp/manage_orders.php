<?php require 'header.php'; ?>
<h1>Manage Orders</h1>
<table>
    <tr>
        <th>Order ID</th>
        <th>Customer</th>
        <th>Order Date</th>
        <th>Total</th>
        <th>Status</th>
        <th>Actions</th>
    </tr>
    <?php
    $result = pg_query($conn, "SELECT * FROM orders");
    while ($row = pg_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>{$row['id']}</td>";
        echo "<td>{$row['customer']}</td>";
        echo "<td>{$row['order_date']}</td>";
        echo "<td>{$row['total']}</td>";
        echo "<td>{$row['status']}</td>";
                echo "<td><a href='view_order.php?id={$row['id']}'>View</a> | <a href='update_order_status.php?id={$row['id']}'>Update Status</a></td>";
        echo "</tr>";
    }
    ?>
</table>
<?php require 'footer.php'; ?>

