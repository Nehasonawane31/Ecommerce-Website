<?php require 'header.php'; ?>
<h1>View Orders</h1>
<table>
    <tr>
        <th>Order ID</th>
        <th>Order Date</th>
        <th>Total</th>
        <th>Status</th>
    </tr>
    <?php
    $result = pg_query($conn, "SELECT * FROM orders WHERE customer = '{$_SESSION['customer']}'");
    while ($row = pg_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>{$row['id']}</td>";
        echo "<td>{$row['order_date']}</td>";
        echo "<td>{$row['total']}</td>";
        echo "<td>{$row['status']}</td>";
        echo "</tr>";
    }
    ?>
</table>
<?php require 'footer.php'; ?>

