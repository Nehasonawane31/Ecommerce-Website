<footer>
  <div class="container">
    <p>&copy; 2024 Neha's eCommerce Website</p>
    <p>Contact Us: <a href="mailto:info@nehasecommerce.com">info@nehasecommerce.com</a></p>
    <ul>
      <li><a href="about.php">About Us</a></li>
      <li><a href="faq.php">FAQ</a></li>
      <li><a href="contact.php">Contact</a></li>
    </ul>
  </div>
</footer>

