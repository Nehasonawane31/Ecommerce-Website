
<?php require 'header.php'; ?>
<h1>Thank You for Your Order!</h1>
<p>Your order has been successfully placed.</p>
<?php require 'footer.php'; ?>
