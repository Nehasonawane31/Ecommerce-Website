<?php
require 'db.php'; // Include your database connection file
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = pg_escape_string($_POST['email']);
    $password = pg_escape_string($_POST['password']);

    // Query to check user credentials
    $query = "SELECT * FROM users WHERE email = $1 AND password = $2";
    $result = pg_query_params($conn, $query, array($email, $password));

    if (pg_num_rows($result) > 0) {
        // Login successful
        $_SESSION['user'] = $email;
        header('Location: index.php?login=success');
    } else {
        // Login failed
        header('Location: login.html?error=invalid_credentials');
    }
}
?>
