<?php
require 'db.php';
require 'header.php';

$product_id = intval($_GET['id']);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $price = htmlspecialchars($_POST['price']);
    $image = $_FILES['image'];

    // Handle image upload
    if ($image['error'] == UPLOAD_ERR_OK) {
        $upload_dir = 'images/';
        $image_path = $upload_dir . basename($image['name']);
        move_uploaded_file($image['tmp_name'], $image_path);
        $image_name = basename($image['name']);
    } else {
        $image_name = $_POST['existing_image']; // Keep the existing image if no new one uploaded
    }

    // Update product in the database
    $query = "UPDATE products SET name = '$name', price = '$price', image = '$image_name' WHERE id = $product_id";
    pg_query($conn, $query);
}

// Fetch existing product details
$query = "SELECT * FROM products WHERE id = $product_id";
$result = pg_query($conn, $query);
$product = pg_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
</head>
<body>
    <h1>Edit Product</h1>
    <form action="edit_product.php?id=<?php echo $product_id; ?>" method="post" enctype="multipart/form-data">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" required><br>
        <label for="price">Price:</label>
        <input type="text" id="price" name="price" value="<?php echo htmlspecialchars($product['price']); ?>" required><br>
        <label for="image">Image:</label>
        <input type="file" id="image" name="image" accept="image/*"><br>
        <input type="hidden" name="existing_image" value="<?php echo htmlspecialchars($product['image']); ?>">
        <input type="submit" value="Update Product">
    </form>
</body>
</html>

<?php require 'footer.php'; ?>
