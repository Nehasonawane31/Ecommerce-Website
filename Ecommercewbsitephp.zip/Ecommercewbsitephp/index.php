<?php
require 'db.php';
require 'header.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Product Listing</title>
    <style>
        body {
            background-color: #333;
            color: white;
            font-family: Arial, sans-serif;
        }
        .product-list {
            list-style-type: none;
            padding: 0;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
        .product-box {
            background-color: #444;
            border: 1px solid #666;
            border-radius: 8px;
            padding: 15px;
            margin: 10px;
            width: 220px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .product-box:hover {
            transform: scale(1.05);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.7);
        }
        .product-image {
            width: 200px;
            height: 200px;
            object-fit: cover;
            margin-bottom: 10px;
        }
        .product-name {
            font-weight: bold;
            font-size: 1.2em;
            margin-bottom: 10px;
        }
        .product-price {
            color: #0f0;
            font-size: 1.1em;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <h1>Products</h1>
    <ul class="product-list">
        <?php
        $result = pg_query($conn, "SELECT * FROM products");
        if (!$result) {
            echo "<p>Error: " . pg_last_error($conn) . "</p>";
        } elseif (pg_num_rows($result) == 0) {
            echo "<p>No products found.</p>";
        } else {
            while ($row = pg_fetch_assoc($result)) {
                $product_id = htmlspecialchars($row['id']);
                $product_name = htmlspecialchars($row['name']);
                $product_price = htmlspecialchars($row['price']);
                $product_image = htmlspecialchars($row['image']);

                // Determine the image path
                if ($product_image && file_exists("images/$product_image")) {
                    $image_path = "images/$product_image";
                } else {
                    $image_path = "images/default.jpg";
                }

                echo "<li class='product-box'>";
                echo "<a href='product_detail.php?id=$product_id'>";
                echo "<img src='$image_path' alt='$product_name' class='product-image'>";
                echo "<div class='product-name'>$product_name</div>";
                echo "<div class='product-price'>\$$product_price</div>";
                echo "</a>";
                echo "</li>";
            }
        }
        ?>
    </ul>
</body>
</html>

<?php require 'footer.php'; ?>
