<?php require 'header.php'; ?>
<div class="cart-container">
      <b style="color: #FF69B4; font-size: 50px;">Shopping Cart</b> 

    <table>
        <tr>
            <th>Product</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Total</th>
        </tr>
        <?php
        $cart = $_SESSION['cart'];
        foreach ($cart as $product_id => $quantity) {
            $result = pg_query_params($conn, "SELECT * FROM products WHERE id = $1", array($product_id));
            $product = pg_fetch_assoc($result);
            echo "<tr>";
            echo "<td>{$product['name']}</td>";
            echo "<td>$quantity</td>";
            echo "<td>{$product['price']}</td>";
            echo "<td>" . ($quantity * $product['price']) . "</td>";
            echo "</tr>";
        }
        ?>
    </table>
    <p>Total: <?php echo $_SESSION['total']; ?></p>
    <a href="checkout.php">Checkout</a>
</div>
<div><?php require 'footer.php'; ?>
</div>
