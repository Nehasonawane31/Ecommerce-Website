
<?php require 'header.php'; ?>
<main>
    <h1>Frequently Asked Questions (FAQ)</h1>
    <section class="faq-section">
        <div class="faq-item">
            <h2>What is your return policy?</h2>
            <p>
                We offer a 30-day return policy on most products. If you are not satisfied with your purchase, please
                contact our customer service team to initiate a return. Please ensure that the product is in its original
                condition and packaging.
            </p>
        </div>
        <div class="faq-item">
            <h2>How can I track my order?</h2>
            <p>
                Once your order has shipped, you will receive a tracking number via email. You can use this tracking
                number to monitor the status of your shipment on our carrier's website.
            </p>
        </div>
        <div class="faq-item">
            <h2>Do you offer international shipping?</h2>
            <p>
                Yes, we offer international shipping to select countries. During checkout, you can select your shipping
                destination to see the available shipping options and rates.
            </p>
        </div>
        <div class="faq-item">
            <h2>How can I contact customer support?</h2>
            <p>
                You can contact our customer support team through the <a href="contact.php">Contact Us</a> page. We are
                available via email, phone, and live chat during business hours.
            </p>
        </div>
    </section>
</main>
<?php require 'footer.php'; ?>
