
<?php require 'header.php'; ?>
<h1>Update Order Status</h1>
<form action="process_update_order_status.php" method="post">
    <label for="status">Status:</label>
    <select id="status" name="status">
        <option value="pending">Pending</option>
        <option value="shipped">Shipped</option>
        <option value="delivered">Delivered</option>
        <option value="cancelled">Cancelled</option>
    </select><br>
    <input type="hidden" name="id" value="<?php echo htmlspecialchars($order['id']); ?>">
    <input type="submit" value="Update Status">
</form>
<?php require 'footer.php'; ?>


