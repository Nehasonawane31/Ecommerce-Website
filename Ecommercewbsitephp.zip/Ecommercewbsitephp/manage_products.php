<?php require 'header.php'; ?>
<h1>Manage Products</h1>
<table>
    <tr>
        <th>Product</th>
        <th>Price</th>
        <th>Actions</th>
    </tr>
    <?php
    $result = pg_query($conn, "SELECT * FROM products");
    while ($row = pg_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>{$row['name']}</td>";
        echo "<td>{$row['price']}</td>";
        echo "<td><a href='edit_product.php?id={$row['id']}'>Edit</a> | <a href='delete_product.php?id={$row['id']}'>Delete</a></td>";
        
            
                    echo "</tr>";
    }
    ?>
</table>
<a href="add_product.php">Add Product</a>
<?php require 'footer.php'; ?>

