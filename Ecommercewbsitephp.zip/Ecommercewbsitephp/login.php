<?php require 'header.php';?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <script>
        window.onload = function() {
            var urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('error') && urlParams.get('error') === 'invalid_credentials') {
                alert("Invalid email or password. Please try again.");
            } else if (urlParams.has('login') && urlParams.get('login') === 'success') {
                alert("Login successful!");
            }
        };
    </script>
</head>
<body>
    <h1>Login</h1>
    <form action="process_login.php" method="post">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br>
        <input type="submit" value="Login">
    </form>
</body>
</html>
