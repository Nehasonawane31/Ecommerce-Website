<?php
require 'db.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = pg_escape_string($_POST['name']);
    $price = (float)$_POST['price'];
    $image = $_FILES['image']['name'];
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
    $query = "INSERT INTO products (name, price, image) VALUES ('$name', $price, '$image')";
    $result = pg_query($conn, $query);
    if (!$result) {
        die("Error in SQL query: " . pg_last_error());
    }
    header('Location: manage_products.php');
}
?>

