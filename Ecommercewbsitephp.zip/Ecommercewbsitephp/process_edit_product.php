
<?php
require 'db.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $name = pg_escape_string($_POST['name']);
    $price = (float)$_POST['price'];
    $query = "UPDATE products SET name = '$name', price = $price WHERE id = $id";
    $result = pg_query($conn, $query);
    if (!$result) {
        die("Error in SQL query: " . pg_last_error());
    }
    header('Location: manage_products.php');
}
?>
