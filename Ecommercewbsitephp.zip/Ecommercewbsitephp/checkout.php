
<?php require 'header.php'; ?>
<h1>Checkout</h1>
<form action="process_payment.php" method="post">
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" required><br>
    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required><br>
    <label for="address">Address:</label>
    <input type="text" id="address" name="address" required><br>
    <label for="payment_method">Payment Method:</label>
    <select id="payment_method" name="payment_method">
        <option value="credit_card">Credit Card</option>
        <option value="paypal">PayPal</option>
    </select><br>
    <input type="submit" value="Place Order">
</form>
<?php require 'footer.php'; ?>
