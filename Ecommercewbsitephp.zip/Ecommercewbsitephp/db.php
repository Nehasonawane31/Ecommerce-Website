<?php
$host = "localhost";
$port = 5432;
$dbname = "ecommerce";
$user = "postgres";
$password = "1234";

$conn = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

if (!$conn) {
    die("Error connecting to database: " . pg_last_error());
} else {
    echo "Connected to database successfully!";
}
?>


