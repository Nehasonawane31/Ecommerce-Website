
<?php require 'header.php'; ?>
<main>
    <h1>About Us</h1>
    <section class="about-content">
        <div class="about-text">
            <h2>Welcome to Our E-commerce Website</h2>
            <p>
                We are a dedicated team committed to providing the best products and services to our customers.
                Our journey started with a vision to create an online platform where quality meets affordability.
                With a wide range of products across various categories, we strive to offer an exceptional shopping
                experience.
            </p>
            <p>
                Our mission is to deliver high-quality products with excellent customer service. We believe in
                building long-term relationships with our customers by consistently exceeding their expectations.
            </p>
            <p>
                Thank you for visiting our website. If you have any questions or feedback, please do not hesitate
                to <a href="contact.php">contact us</a>.
            </p>
        </div>
    </section>
</main>
<?php require 'footer.php'; ?>
