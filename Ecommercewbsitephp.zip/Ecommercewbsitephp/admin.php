
<?php require 'header.php'; ?>
<h1>Admin Portal</h1>
<p>Welcome, <?php echo $_SESSION['user']; ?>!</p>
<ul>
    <li><a href="manage_products.php">Manage Products</a></li>
    <li><a href="manage_orders.php">Manage Orders</a></li>
    <li><a href="logout.php">Logout</a></li>
</ul>
<?php require 'footer.php'; ?>

