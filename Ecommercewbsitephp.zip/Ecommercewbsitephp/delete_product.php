<?php
require 'db.php';
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "DELETE FROM products WHERE id = $id";
    $result = pg_query($conn, $query);
    if (!$result) {
        die("Error in SQL query: " . pg_last_error());
    }
    header('Location: manage_products.php');
}
?>

