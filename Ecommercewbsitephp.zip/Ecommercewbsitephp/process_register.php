<?php
require 'db.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = pg_escape_string($_POST['name']);
    $email = pg_escape_string($_POST['email']);
    $password = pg_escape_string($_POST['password']);
    // Check email in database
    // ...
    if (!$exists) {
        // Insert into database
        // ...
        $_SESSION['user'] = $email;
        header('Location: index.php');
    } else {
        header('Location: register.php?error=email_taken');
    }
}
?>

