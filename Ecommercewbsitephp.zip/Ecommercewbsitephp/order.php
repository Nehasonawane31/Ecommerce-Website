<?php
session_start();
require 'db.php';
require 'header.php';

// Check if the user is logged in
if (!isset($_SESSION['customer_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_id = intval($_POST['product_id']);
    $quantity = intval($_POST['quantity']);
    
    // Fetch product details
    $result = pg_query($conn, "SELECT * FROM products WHERE id = $product_id");
    $product = pg_fetch_assoc($result);
    
    if ($product) {
        $total_price = $product['price'] * $quantity;
        $customer_id = $_SESSION['customer_id'];
        
        // Insert order into the database
        $query = "INSERT INTO orders (product_id, quantity, total_price, customer_id, order_date, status) 
                  VALUES ($product_id, $quantity, $total_price, $customer_id, NOW(), 'pending')";
        $result = pg_query($conn, $query);
        
        if ($result) {
            $order_id = pg_fetch_result(pg_query($conn, "SELECT currval(pg_get_serial_sequence('orders','id'))"), 0, 0);
            header("Location: view_order.php?order_id=$order_id");
            exit;
        } else {
            echo "Failed to place order.";
        }
    } else {
        echo "Product not found.";
    }
} else {
    echo "Invalid request.";
}

require 'footer.php';
?>
