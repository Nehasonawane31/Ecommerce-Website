<?php require 'header.php'; ?> 

<h1>Customer Dashboard</h1> 
<h2>Welcome, <?php echo $_SESSION['customer']; ?>!</h2> 

<ul> 
  <li style="font-size:30px;"><a href="view_orders.php" style="color:white;">View Orders</a></li> 
  <li style="font-size:30px;"><a href="logout.php" style="color:white;">Logout</a></li> 
</ul> 

<?php require 'footer.php'; ?>
