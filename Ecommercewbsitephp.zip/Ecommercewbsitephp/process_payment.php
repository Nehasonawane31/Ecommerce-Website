<?php
require 'db.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = pg_escape_string($_POST['name']);
    $email = pg_escape_string($_POST['email']);
    $address = pg_escape_string($_POST['address']);
    $payment_method = pg_escape_string($_POST['payment_method']);
    // Process payment
    // ...
    // Clear cart and total
    $_SESSION['cart'] = array();
    $_SESSION['total'] = 0;
    header('Location: thank_you.php');
}
?>

