<?php require 'header.php'; ?>
<h1>View Order</h1>
<p>Order ID: <?php echo htmlspecialchars($order['id']); ?></p>
<p>Customer: <?php echo htmlspecialchars($order['customer']); ?></p>
<p>Order Date: <?php echo htmlspecialchars($order['order_date']); ?></p>
<p>Total: <?php echo htmlspecialchars($order['total']); ?></p>
<p>Status: <?php echo htmlspecialchars($order['status']); ?></p>
<table>
    <tr>
        <th>Product</th>
        <th>Quantity</th>
        <th>Price</th>
    </tr>
    <?php
    $result = pg_query($conn, "SELECT * FROM order_items WHERE order_id = {$order['id']}");
    while ($row = pg_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>{$row['product']}</td>";
        echo "<td>{$row['quantity']}</td>";
        echo "<td>{$row['price']}</td>";
        echo "</tr>";
    }
    ?>
</table>
<?php require 'footer.php'; ?>


