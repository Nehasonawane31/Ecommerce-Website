<?php
require 'db.php';
require 'header.php';

$product_id = intval($_GET['id']);
$query = "SELECT * FROM products WHERE id = $product_id";
$result = pg_query($conn, $query);
$product = pg_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Product Detail</title>
</head>
<body>
    <h1>Product Detail</h1>
    <?php if ($product): ?>
        <img src="images/<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="product-image">
        <h2><?php echo htmlspecialchars($product['name']); ?></h2>
        <p>Price: $<?php echo htmlspecialchars($product['price']); ?></p>
        <p>Description: <?php echo htmlspecialchars($product['description']); ?></p>
        <form action="add_to_cart.php" method="post">
            <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product['id']); ?>">
            <input type="number" name="quantity" value="1" min="1">
            <input type="submit" value="Add to Cart">
        </form>
    <?php else: ?>
        <p>Product not found.</p>
    <?php endif; ?>
</body>
</html>

<?php require 'footer.php'; ?>
